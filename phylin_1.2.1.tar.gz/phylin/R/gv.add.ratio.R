gv.add.ratio <- function(gv, clades) {
  if (class(gv) != 'gv') stop("Object must be of class 'gv'")
  if (length(clades) != nrow(gv$x)) {
    stop(paste("Clades must have the same number of items as the",
               "variogram distance matrix"))
  }

  lags <- seq(0, gv$param$lmax, gv$param$lag)
  ratio <- rep(NA, length(lags))
  tol <- gv$param$tol
  for (i in 1:length(lags)) {
    il <- which(x$x > lags[i]-tol & x$x <= lags[i]+tol, arr.ind=TRUE)
    if (nrow(il) > 0) {
      il <- unique(t(apply(il, 1, sort)))
      cld <- cbind(clades[il[,1]], clades[il[,2]])
      ratio[i] = sum(cld[,1]==cld[,2]) / nrow(cld)
    }
  }
  
}
